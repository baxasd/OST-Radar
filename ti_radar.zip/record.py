"""
OST Radar Recorder — Research Tool
====================================
Edit the SESSION and RADAR SETTINGS constants below, then run:
    python record.py

Controls (keyboard shortcuts in the plot window):
    R  — Start / Stop recording
    Q  — Quit and close
"""

import sys
import time
import json
import threading
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import pandas as pd
import pyqtgraph as pg

from PyQt6.QtCore import QThread, pyqtSignal, Qt
from PyQt6.QtWidgets import QApplication, QMainWindow
from PyQt6.QtGui import QShortcut, QKeySequence

try:
    from ti_radar.sensor import RadarSensor
    RADAR_AVAILABLE = True
except ImportError:
    RADAR_AVAILABLE = False

from rich.console import Console
from rich.table import Table
from rich import box

# ─────────────────────────────────────────────
#  SESSION  — edit these before each run
# ─────────────────────────────────────────────
SUBJECT  = "S01"        # Subject ID
ACTIVITY = "running"    # Activity label
TEMP     = 24.0         # Ambient temperature (°C)

# ─────────────────────────────────────────────
#  RADAR SETTINGS  — change only when hardware changes
# ─────────────────────────────────────────────
CFG_FILE  = "ti_radar/profile_3d_ISK.cfg"
MAX_RANGE = 5.0         # Range crop in metres
CLI_PORT  = None        # e.g. "COM3" — None = auto-detect
DATA_PORT = None        # e.g. "COM4" — None = auto-detect

# ─────────────────────────────────────────────
#  DISPLAY SETTINGS
# ─────────────────────────────────────────────
CMAP             = "inferno"
DISPLAY_LOW_PCT  = 40     # Percentile clip low  (raise if image looks noisy)
DISPLAY_HIGH_PCT = 99.5   # Percentile clip high (lower if image looks washed out)

console = Console()


# ─────────────────────────────────────────────
#  WORKER THREAD  (serial read lives here so
#  it never blocks the Qt render loop)
# ─────────────────────────────────────────────
class RadarWorker(QThread):
    new_frame = pyqtSignal(np.ndarray)  # emits display matrix (range x doppler)
    error     = pyqtSignal(str)

    def __init__(self, radar: "RadarSensor", max_range_m: float):
        super().__init__()
        self.radar     = radar
        self.running   = True
        self.recording = False  # read by worker thread, written by main thread

        # FIX 1: threading.Lock() guards the frame buffer.
        # Without this, stop_recording() on the main thread can read
        # self._frames while the worker is mid-append — corrupting the list.
        self._lock       = threading.Lock()
        self._frames:     list[np.ndarray] = []
        self._timestamps: list[float]      = []

        cfg = radar.config
        self.num_range_bins = cfg.ADCsamples
        self.num_vel_bins   = cfg.numLoops

        # Clamp to num_range_bins to prevent out-of-bounds slice if
        # MAX_RANGE exceeds the radar's physical maximum range.
        self.max_bin   = min(int(max_range_m / cfg.rangeRes), self.num_range_bins)
        self.range_res = cfg.rangeRes

    # ── public API (called from main thread) ──────────────────────────────
    def start_recording(self):
        # Acquire lock before clearing — worker may be appending right now
        with self._lock:
            self._frames.clear()
            self._timestamps.clear()
        self.recording = True   # set AFTER clearing so no frames are missed

    def stop_recording(self) -> tuple[list, list]:
        self.recording = False  # set BEFORE acquiring lock to stop new appends
        with self._lock:
            return list(self._frames), list(self._timestamps)

    def stop(self):
        self.running = False
        self.wait()

    # ── thread loop ───────────────────────────────────────────────────────
    def run(self):
        while self.running:
            try:
                frame = self.radar.get_next_frame()
                if not frame or frame.get("RDHM") is None:
                    continue

                raw      = frame["RDHM"]
                expected = self.num_range_bins * self.num_vel_bins
                if raw.size != expected:
                    continue

                # Reshape and crop to max range
                rd = raw.astype(np.float32).reshape(self.num_range_bins, self.num_vel_bins)
                rd = rd[:self.max_bin, :]

                # FIX 2: Timestamp captured immediately after frame arrives —
                # before any numpy work. Even a few ms of processing skew
                # would corrupt inter-frame intervals and cadence FFT downstream.
                ts = time.time()

                # Store raw (pre-shift) physics data for analysis.
                # fftshift and log scaling are for display only — never stored.
                if self.recording:
                    with self._lock:
                        self._frames.append(rd.copy())
                        self._timestamps.append(ts)

                # Display: shift 0-velocity to centre, convert to dB.
                # fftshift on axis=1 only (doppler axis). axis=0 is range.
                display = np.fft.fftshift(rd, axes=1)
                display = 20.0 * np.log10(np.abs(display) + 1e-6)
                self.new_frame.emit(display)

            except Exception as e:
                self.error.emit(str(e))


# ─────────────────────────────────────────────
#  MAIN WINDOW  (plot only — no sidebar, no
#  widgets beyond the pyqtgraph canvas)
# ─────────────────────────────────────────────
class RecorderWindow(QMainWindow):
    def __init__(self, radar: "RadarSensor"):
        super().__init__()
        self.radar     = radar
        self.worker    = None
        self.recording = False

        # FPS tracking
        self._prev_time   = time.time()
        self._fps         = 0.0
        self._frame_count = 0  # total frames received
        self._rec_frames  = 0  # frames in current recording

        self._build_plot(radar)
        self._bind_keys()
        self._start_worker(radar)

        self.setWindowTitle(
            f"OST Radar Recorder  |  {SUBJECT} / {ACTIVITY}  "
            f"|  [R] Record   [Q] Quit"
        )

    # ── plot setup ────────────────────────────────────────────────────────
    def _build_plot(self, radar):
        cfg = radar.config

        # FIX 3: Axis rect must use the same max_bin as the worker.
        # Previously _build_plot and RadarWorker each computed max_bin
        # independently — any rounding difference misaligns the range axis
        # so displayed range values are wrong.
        # Both now use: int(MAX_RANGE / cfg.rangeRes), clamped to ADCsamples.
        max_bin      = min(int(MAX_RANGE / cfg.rangeRes), cfg.ADCsamples)
        actual_max_m = max_bin * cfg.rangeRes  # true range extent of stored data

        # Velocity axis: numLoops doppler bins, centred at 0 after fftshift.
        # Half-bin offset aligns pixel edges with axis ticks correctly.
        max_v   = (cfg.numLoops / 2.0) * cfg.dopRes
        dop_res = cfg.dopRes

        self.plot = pg.PlotWidget(title="Live Micro-Doppler Spectrogram")
        self.plot.setLabel("left",   "Range",    units="m")
        self.plot.setLabel("bottom", "Velocity", units="m/s")
        self.plot.showGrid(x=True, y=True, alpha=0.3)

        # Zero-velocity reference line
        self.plot.addItem(pg.InfiniteLine(
            pos=0, angle=90,
            pen=pg.mkPen("w", style=Qt.PenStyle.DashLine, width=1)
        ))

        self.img = pg.ImageItem()
        self.img.setColorMap(pg.colormap.get(CMAP))
        self.plot.addItem(self.img)

        # rect = (x_left, y_bottom, width, height) in physical units.
        # x → velocity (doppler), y → range.
        self._rect = pg.QtCore.QRectF(
            -max_v - dop_res / 2.0,  # left edge  (most negative velocity)
            0,                        # bottom edge (0 m range)
            max_v * 2.0,              # width       (full velocity span)
            actual_max_m              # height      (true range extent)
        )
        self.img.setRect(self._rect)

        self.setCentralWidget(self.plot)
        self.resize(900, 650)

    # ── keyboard shortcuts ────────────────────────────────────────────────
    def _bind_keys(self):
        QShortcut(QKeySequence("R"), self).activated.connect(self._toggle_recording)
        QShortcut(QKeySequence("r"), self).activated.connect(self._toggle_recording)
        QShortcut(QKeySequence("Q"), self).activated.connect(self.close)
        QShortcut(QKeySequence("q"), self).activated.connect(self.close)

    # ── worker lifecycle ──────────────────────────────────────────────────
    def _start_worker(self, radar):
        self.worker = RadarWorker(radar, MAX_RANGE)
        self.worker.new_frame.connect(self._on_frame)
        self.worker.error.connect(lambda e: console.print(f"[red]Worker error:[/red] {e}"))
        self.worker.start()

    # ── frame handler (runs on main/Qt thread via signal) ─────────────────
    def _on_frame(self, matrix: np.ndarray):
        now = time.time()
        dt  = now - self._prev_time
        self._fps       = 1.0 / dt if dt > 0 else 0.0
        self._prev_time = now
        self._frame_count += 1

        if self.recording:
            self._rec_frames += 1

        lo = float(np.percentile(matrix, DISPLAY_LOW_PCT))
        hi = float(np.percentile(matrix, DISPLAY_HIGH_PCT))

        self.img.setImage(matrix, autoLevels=False, levels=(lo, hi))
        self.img.setRect(self._rect)  # re-apply every frame — pyqtgraph can drift

        state = "[REC ●]" if self.recording else "[LIVE]"
        self.setWindowTitle(
            f"OST Radar  {state}  "
            f"FPS: {self._fps:.1f}  "
            f"Frames: {self._frame_count}"
            + (f"  Rec: {self._rec_frames}" if self.recording else "")
            + "  |  [R] Record   [Q] Quit"
        )

    # ── recording control ─────────────────────────────────────────────────
    def _toggle_recording(self):
        if not self.recording:
            self.recording   = True
            self._rec_frames = 0
            self.worker.start_recording()
            console.print(
                f"\n[bold red]● RECORDING STARTED[/bold red]  "
                f"Subject=[cyan]{SUBJECT}[/cyan]  "
                f"Activity=[cyan]{ACTIVITY}[/cyan]"
            )
        else:
            self.recording = False
            frames, timestamps = self.worker.stop_recording()
            console.print(
                f"[bold green]■ RECORDING STOPPED[/bold green]  "
                f"{len(frames)} frames captured"
            )
            if frames:
                self._save(frames, timestamps)

    # ── save ──────────────────────────────────────────────────────────────
    def _save(self, frames: list[np.ndarray], timestamps: list[float]):
        cfg      = self.radar.config
        filename = f"radar_{SUBJECT}_{ACTIVITY}_{int(time.time())}.parquet"

        metadata = {
            "subject":     SUBJECT,
            "activity":    ACTIVITY,
            "temp":        TEMP,
            "range_res":   cfg.rangeRes,
            "doppler_res": cfg.dopRes,
            "dop_max":     cfg.dopMax,
        }

        df = pd.DataFrame({
            "timestamp":  timestamps,
            "frame_data": [f.tobytes() for f in frames],
        })

        # FIX 4: Store dtype as numpy canonical string e.g. "<f4" not "float32".
        # dtype.str round-trips perfectly on all platforms and byte orders.
        # "float32" works on little-endian but silently fails on big-endian.
        table = pa.Table.from_pandas(df)
        table = table.replace_schema_metadata({
            **(table.schema.metadata or {}),
            b"radar_metadata": json.dumps(metadata).encode(),
            b"frame_shape":    json.dumps(list(frames[0].shape)).encode(),
            b"frame_dtype":    frames[0].dtype.str.encode(),
        })

        pq.write_table(table, filename)
        console.print(f"[bold green]✓ Saved:[/bold green] [white]{filename}[/white]")

    # ── cleanup ───────────────────────────────────────────────────────────
    def closeEvent(self, event):
        if self.worker:
            self.worker.stop()
        if self.radar:
            self.radar.close()
        event.accept()


# ─────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────
def connect_radar() -> "RadarSensor":
    cli_port  = CLI_PORT
    data_port = DATA_PORT

    if cli_port is None or data_port is None:
        console.print("[yellow]Auto-detecting TI radar ports...[/yellow]")
        detected_cli, detected_data = RadarSensor.find_ti_ports()
        cli_port  = cli_port  or detected_cli
        data_port = data_port or detected_data

    if not cli_port or not data_port:
        console.print(
            "[bold red]ERROR:[/bold red] Could not find radar ports. "
            "Set CLI_PORT and DATA_PORT manually at the top of record.py"
        )
        sys.exit(1)

    console.print(f"Connecting — CLI: [cyan]{cli_port}[/cyan]  DATA: [cyan]{data_port}[/cyan]")
    radar = RadarSensor(cli_port, data_port, CFG_FILE)
    radar.connect_and_configure()
    return radar


def print_session_info(radar):
    cfg   = radar.config
    table = Table(title="Session Info", box=box.ROUNDED, show_header=False)
    table.add_column("Key",   style="dim")
    table.add_column("Value", style="cyan bold")

    table.add_row("Subject",      SUBJECT)
    table.add_row("Activity",     ACTIVITY)
    table.add_row("Temperature",  f"{TEMP} °C")
    table.add_row("Max Range",    f"{MAX_RANGE} m")
    table.add_row("Range Res",    f"{cfg.rangeRes * 100:.2f} cm")
    table.add_row("Doppler Res",  f"{cfg.dopRes:.3f} m/s")
    table.add_row("Max Velocity", f"±{cfg.dopMax:.2f} m/s")
    table.add_row("Frame Rate",   f"{1e3 / cfg.T:.1f} Hz  ({cfg.T:.0f} ms)")
    table.add_row("",             "")
    table.add_row("Controls",     "[R] Record / Stop   [Q] Quit")

    console.print(table)


def main():
    if not RADAR_AVAILABLE:
        console.print(
            "[bold red]ERROR:[/bold red] ti_radar module not found. "
            "Run from the project root directory."
        )
        sys.exit(1)

    radar = connect_radar()

    app = QApplication(sys.argv)
    pg.setConfigOptions(imageAxisOrder="row-major", antialias=False)

    print_session_info(radar)

    window = RecorderWindow(radar)
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()